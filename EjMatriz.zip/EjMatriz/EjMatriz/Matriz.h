#pragma once
#define MAX 20

class Matriz
{
private:
    int MAT[MAX][MAX];
    int fil;
    int col;
public:
    Matriz(); // Constructor
    ~Matriz(); // Destructor
    // M�todos que modifican o retornan los atributos
    int get_fil();
    int get_col();
    void set_fil(int _fil);
    void set_col(int _col);
    void mostrarmat(); // No necesita pasar MAT[MAX][MAX] como argumento
    void cargarmat(); // No necesita pasar MAT[MAX][MAX] como argumento
    float promedio();
    int mayor();
};


