#include "Matriz.h"
#include <iostream>
using namespace std;

Matriz::Matriz() {
    // Inicializar fil y col en 0 para evitar valores indeseados
    fil = 0;
    col = 0;
    // Inicializar MAT en 0 para indicar que est� vac�a
    for (int i = 0; i < MAX; i++) {
        for (int j = 0; j < MAX; j++) {
            MAT[i][j] = 0;
        }
    }
}

Matriz::~Matriz() {
    // No hay nada que destruir en este caso
}

int Matriz::get_fil() {
    return fil;
}

int Matriz::get_col() {
    return col;
}

void Matriz::set_fil(int _fil) {
    fil = _fil;
}

void Matriz::set_col(int _col) {
    col = _col;
}

void Matriz::mostrarmat() {
    if (fil == 0 || col == 0) {
        cout << "La matriz est� vac�a." << endl;
    }
    else {
        for (int i = 0; i < fil; i++) {
            for (int j = 0; j < col; j++) {
                cout << MAT[i][j] << "\t";
            }
            cout << endl;
        }
    }
}

void Matriz::cargarmat() {
    for (int i = 0; i < fil; i++)
        for (int j = 0; j < col; j++) {
            cout << "MAT[" << i << "][" << j << "]= ";
            cin >> MAT[i][j];
        }
}

float Matriz::promedio() {
    float prom = 0; // Inicializar promedio en 0
    float s = 0;
    for (int i = 0; i < fil; i++)
        for (int j = 0; j < col; j++)
            s = s + MAT[i][j];
    // Calcular promedio correctamente
    prom = s / (fil * col);
    return prom;
}

int Matriz::mayor() {
    int may = MAT[0][0];
    for (int i = 0; i < fil; i++)
        for (int j = 0; j < col; j++)
            if (MAT[i][j] > may)
                may = MAT[i][j];
    return may;
}


