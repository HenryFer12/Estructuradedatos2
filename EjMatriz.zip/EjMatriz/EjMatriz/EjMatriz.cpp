#include <iostream>
#include "Matriz.h"
using namespace std;

int main() {
    Matriz matrix;
    int fil, col, opc;
    float prom;

    do {
        cout << "Ingrese el numero de filas: ";
        cin >> fil;
    } while (fil <= 0 || fil > MAX);

    do {
        cout << "Ingrese el numero de columnas: ";
        cin >> col;
    } while (col <= 0 || col > MAX);

    matrix.set_fil(fil);
    matrix.set_col(col);

    do {
        cout << "\t Menu\n";
        cout << "\t ====\n\n";
        cout << "(1) Cargar Matriz\n";
        cout << "(2) Mostrar Matriz\n";
        cout << "(3) Promedio Matriz\n";
        cout << "(4) Mayor Matriz\n";
        cout << "(0) Salir\n";
        cout << "Opcion:";
        cin >> opc;
        switch (opc) {
        case 1:
            matrix.cargarmat();
            break;
        case 2:
            matrix.mostrarmat();
            break;
        case 3:
            prom = matrix.promedio();
            cout << "El valor promedio es: " << prom << endl;
            break;
        case 4:
            cout << "El mayor es: " << matrix.mayor() << endl;
            break;
        case 0:
            cout << "Salir\n";
            break;
        default:
            cout << "Error\n";
            break;
        }
    } while (opc != 0);
    return 0;
}
