#include <iostream>
#include <string>

#define MAX 100
using namespace std;
class LIBRO
{
private:
    string dato[MAX];
    int inicio, fin;

public:
    LIBRO(void);
    bool Encolar(const string& Valor);
    bool Desencolar(void);
    bool PrimeroCola(std::string& valor);
    bool ColaVacia(void);
    void Mostrar(void);
};

LIBRO::LIBRO(void)
{
    inicio = 0;
    fin = 0;
}

bool LIBRO::Encolar(const string& Valor)
{
    if (fin == MAX)
        return false;
    else
    {
        dato[fin] = Valor;
        fin++;
        return true;
    }
}

bool LIBRO::Desencolar(void)
{
    if (ColaVacia())
        return false;
    else
    {
        inicio++;
        if (inicio == fin) // Si hemos alcanzado el final de la cola, reiniciamos los índices
        {
            inicio = 0;
            fin = 0;
        }
        return true;
    }
}

bool LIBRO::PrimeroCola(string& Valor)
{
    if (ColaVacia())
        return false;
    else
    {
        Valor = dato[inicio];
        return true;
    }
}

bool LIBRO::ColaVacia(void)
{
    return inicio == fin;
}

void LIBRO::Mostrar(void)
{
    if (ColaVacia()) {
        cout << "La cola está vacía." << std::endl;
    }
    else {
        for (int i = inicio; i < fin; i++)
            cout << "[" << dato[i] << "]" << std::endl;
        cout << std::endl << std::endl;
    }
}


int main()
{
    LIBRO libro;

    int opcion;
    string nombreLibro;

    do {
        cout << "Menu:" << std::endl;
        cout << "1. Encolar libro" << std::endl;
        cout << "2. Desencolar libro" << std::endl;
        cout << "3. Mostrar primer libro en la cola" << std::endl;
        cout << "4. Mostrar todos los libros en la cola" << std::endl;
        cout << "5. Salir" << std::endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
        case 1:
            cout << "Ingrese el nombre del libro a encolar: ";
            cin.ignore(); // Ignorar el salto de línea pendiente en el buffer
            getline(std::cin, nombreLibro);
            if (libro.Encolar(nombreLibro))
                cout << "Libro encolado correctamente." << std::endl;
            else
                cout << "Error: la cola está llena." << std::endl;
            break;
        case 2:
            if (libro.Desencolar())
                cout << "Libro desencolado correctamente." << std::endl;
            else
                cout << "Error: la cola está vacía." << std::endl;
            break;
        case 3:
            if (libro.ColaVacia())
                cout << "La cola está vacía." << std::endl;
            else {
                string primerLibro;
                if (libro.PrimeroCola(primerLibro))
                    cout << "El primer libro en la cola es: " << primerLibro << std::endl;
                else
                    cout << "Error al obtener el primer libro." << std::endl;
            }
            break;
        case 4:
            libro.Mostrar();
            break;
        case 5:
            cout << "Saliendo del programa." << std::endl;
            break;
        default:
            cout << "Opción no válida. Inténtelo de nuevo." << std::endl;
        }
    } while (opcion != 5);

    return 0;
}



